import SocietyAnalytics from '@/components/analytics/SocietyAnalytics'

export default function AnalyticsPage() {
  return <SocietyAnalytics />
}