#!/bin/bash

# Current Repository Complete Backup Script
# Usage: ./current-repo-backup.sh

echo "🚀 Starting Current Repository Complete Backup..."

# Configuration
CURRENT_REPO_DIR=$(pwd)
TARGET_REPO="https://github.com/Sspanwar31/Sspanwar31-saanify-workspace-testing-"
GITHUB_TOKEN="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"
TIMESTAMP=$(date +"%Y-%m-%dT%H-%M-%S")
BACKUP_DIR="current-backup-${TIMESTAMP}"
TEMP_DIR="temp-current-backup-${TIMESTAMP}"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${CYAN}📅 Current Backup Timestamp: ${TIMESTAMP}${NC}"
echo -e "${CYAN}📂 Current Repository: ${CURRENT_REPO_DIR}${NC}"
echo -e "${CYAN}🌐 Target Repository: ${TARGET_REPO}${NC}"

# Create directories
mkdir -p "$TEMP_DIR"
mkdir -p "$BACKUP_DIR"

echo -e "${YELLOW}📊 Step 1: Analyzing current repository...${NC}"

# Analyze current repository
TOTAL_COMMITS=$(git rev-list --all --count 2>/dev/null || echo "0")
TOTAL_BRANCHES=$(git branch -a 2>/dev/null | wc -l || echo "0")
TOTAL_FILES=$(find . -type f -not -path './.git/*' -not -path './.next/*' -not -path './node_modules/*' | wc -l)
TOTAL_SIZE=$(du -sh . --exclude='.git' --exclude='.next' --exclude='node_modules' 2>/dev/null | cut -f1 || echo "Unknown")
LATEST_COMMIT=$(git log -1 --format="%H" 2>/dev/null || echo "No commits")
LATEST_MESSAGE=$(git log -1 --format="%s" 2>/dev/null || echo "No commit message")
LATEST_AUTHOR=$(git log -1 --format="%an" 2>/dev/null || echo "Unknown")

echo -e "${PURPLE}📈 Current Repository Analysis:${NC}"
echo -e "   📊 Total Commits: ${TOTAL_COMMITS}"
echo -e "   🌿 Total Branches: ${TOTAL_BRANCHES}"
echo -e "   📁 Total Files: ${TOTAL_FILES}"
echo -e "   💾 Repository Size: ${TOTAL_SIZE}"
echo -e "   🔗 Latest Commit: ${LATEST_COMMIT:0:8} by ${LATEST_AUTHOR}"
echo -e "   📝 Latest Message: ${LATEST_MESSAGE}"

echo -e "${YELLOW}📦 Step 2: Creating complete repository backup...${NC}"

# Create a copy of current repository for backup
echo -e "${BLUE}📋 Copying current repository...${NC}"
cp -r . "$TEMP_DIR/current-repo"

# Remove unnecessary directories from backup
cd "$TEMP_DIR/current-repo"
rm -rf .next/ node_modules/ 2>/dev/null || true
rm -rf temp-* 2>/dev/null || true
rm -rf complete-backup-* enhanced-backup-* fixed-backup-* 2>/dev/null || true

# Count files in backup
BACKUP_FILES=$(find . -type f -not -path './.git/*' | wc -l)
echo -e "${BLUE}📁 Files to backup: ${BACKUP_FILES}${NC}"

# Go back for tar creation
cd ../..

echo -e "${YELLOW}📦 Step 3: Creating comprehensive backup archive...${NC}"

# Create comprehensive backup archive
ARCHIVE_NAME="current-complete-repo-backup-${TIMESTAMP}.tar.gz"
echo -e "${BLUE}📁 Creating comprehensive archive: ${ARCHIVE_NAME}${NC}"

# Create archive with all repository content
tar -czf "${BACKUP_DIR}/${ARCHIVE_NAME}" \
    --exclude='.git/objects/pack/*.pack' \
    --exclude='.git/objects/pack/*.idx' \
    -C "$TEMP_DIR" \
    current-repo/

if [ $? -eq 0 ]; then
    ARCHIVE_SIZE=$(du -sh "${BACKUP_DIR}/${ARCHIVE_NAME}" | cut -f1)
    echo -e "${GREEN}✅ Archive created successfully (${ARCHIVE_SIZE})${NC}"
else
    echo -e "${RED}❌ Failed to create archive${NC}"
    rm -rf "$TEMP_DIR" "$BACKUP_DIR"
    exit 1
fi

echo -e "${YELLOW}📄 Step 4: Creating detailed metadata...${NC}"

# Create detailed metadata file
METADATA_FILE="${BACKUP_DIR}/current-backup-metadata.json"
cat > "$METADATA_FILE" << EOF
{
  "backupType": "current-repository-complete-backup",
  "timestamp": "$(date -Iseconds)",
  "sourceRepository": "current-working-directory",
  "sourcePath": "${CURRENT_REPO_DIR}",
  "targetRepository": "${TARGET_REPO}",
  "statistics": {
    "totalCommits": ${TOTAL_COMMITS},
    "totalBranches": ${TOTAL_BRANCHES},
    "totalFiles": ${TOTAL_FILES},
    "backupFiles": ${BACKUP_FILES},
    "repositorySize": "${TOTAL_SIZE}",
    "archiveSize": "${ARCHIVE_SIZE}",
    "latestCommit": {
      "hash": "${LATEST_COMMIT}",
      "message": "${LATEST_MESSAGE}",
      "author": "${LATEST_AUTHOR}"
    }
  },
  "backupFiles": {
    "archive": "${ARCHIVE_NAME}",
    "metadata": "current-backup-metadata.json"
  },
  "backupScript": "current-repo-backup.sh",
  "status": "completed"
}
EOF

echo -e "${GREEN}✅ Metadata file created${NC}"

echo -e "${YELLOW}🚀 Step 5: Pushing backup to GitHub...${NC}"

# Setup target repository
TARGET_AUTH_REPO="${TARGET_REPO/https:\/\//https:\/\/$GITHUB_TOKEN@}"

cd "$TEMP_DIR/current-repo"

# Configure git for pushing to target
git remote remove origin 2>/dev/null || true
git remote add origin "$TARGET_AUTH_REPO"
git config user.name "Saanify Current Backup Bot"
git config user.email "current-backup@saanify.com"

# Create backup branch
BACKUP_BRANCH="current-backup-${TIMESTAMP}"
git checkout -b "$BACKUP_BRANCH" 2>/dev/null || git checkout main 2>/dev/null || git checkout master

# Add backup files to repository
cp "../../${BACKUP_DIR}/${ARCHIVE_NAME}" "./${ARCHIVE_NAME}"
cp "../../${METADATA_FILE}" "./current-backup-metadata.json"

# Add and commit backup files
git add .
git commit -m "🚀 Current Repository Complete Backup: $(date -Iseconds)

📊 Repository Statistics:
• Total Commits: ${TOTAL_COMMITS}
• Total Branches: ${TOTAL_BRANCHES}
• Total Files: ${TOTAL_FILES}
• Backup Files: ${BACKUP_FILES}
• Repository Size: ${TOTAL_SIZE}
• Archive Size: ${ARCHIVE_SIZE}
• Latest Commit: ${LATEST_COMMIT:0:8}

📁 Backup Files:
• ${ARCHIVE_NAME}
• current-backup-metadata.json

🔧 Backup Details:
• Source: Current working directory
• Path: ${CURRENT_REPO_DIR}
• Complete repository with all files
• Git history preserved

🤖 Generated by: current-repo-backup.sh"

# Push to target repository
echo -e "${BLUE}📤 Pushing to target repository...${NC}"

if git push -u origin "$BACKUP_BRANCH" --force; then
    echo -e "${GREEN}✅ Current repository backup pushed successfully!${NC}"
    echo -e "${BLUE}📍 Target Repository: ${TARGET_REPO}${NC}"
    echo -e "${BLUE}🌿 Backup Branch: ${BACKUP_BRANCH}${NC}"
    echo -e "${BLUE}🔗 Backup URL: ${TARGET_REPO}/tree/${BACKUP_BRANCH}${NC}"
else
    echo -e "${YELLOW}⚠️ Push to target failed, but backup is available locally${NC}"
fi

# Go back to original directory
cd ../..

echo -e "${YELLOW}🧹 Step 6: Cleanup...${NC}"

# Cleanup temporary files
rm -rf "$TEMP_DIR"

echo -e "${GREEN}🎉 Current Repository Complete Backup Finished!${NC}"
echo -e "${CYAN}📂 Local Backup Location: ${BACKUP_DIR}/${NC}"
echo -e "${CYAN}📁 Archive File: ${BACKUP_DIR}/${ARCHIVE_NAME}${NC}"
echo -e "${CYAN}📄 Metadata File: ${METADATA_FILE}${NC}"

echo -e "${PURPLE}📋 Current Repository Backup Summary:${NC}"
echo -e "   ✅ Current working directory backed up"
echo -e "   ✅ All ${TOTAL_FILES} files included in backup"
echo -e "   ✅ Complete repository history preserved"
echo -e "   ✅ Comprehensive archive created (${ARCHIVE_SIZE})"
echo -e "   ✅ Detailed metadata generated"
echo -e "   ✅ Backup pushed to GitHub"

echo -e "${GREEN}🚀 Current repository backup completed successfully!${NC}"