#!/bin/bash

# Quick GitHub Backup Script for Saanify
# Usage: ./quick-github-backup.sh

echo "🚀 Starting GitHub backup..."

# Configuration
PROJECT_NAME="saanify-workspace"
BACKUP_DIR="./backups"
TEMP_DIR="./temp-github-backup"
GITHUB_REPO="https://github.com/Sspanwar31/Sspanwar31-saanify-workspace-testing-"
GITHUB_BRANCH="main"
GITHUB_TOKEN="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"

# Create backup ID with timestamp
TIMESTAMP=$(date +"%Y-%m-%dT%H-%M-%S-%3NZ")
BACKUP_ID="${PROJECT_NAME}-${TIMESTAMP}"
ARCHIVE_NAME="${BACKUP_ID}.tar.gz"

# Create directories
mkdir -p "$BACKUP_DIR"
mkdir -p "$TEMP_DIR"

echo "📦 Creating backup archive..."

# Create tar.gz backup (excluding unnecessary files)
tar -czf "$TEMP_DIR/$ARCHIVE_NAME" \
    --exclude=node_modules \
    --exclude=.next \
    --exclude=dist \
    --exclude=.git \
    --exclude=*.log \
    --exclude=.DS_Store \
    --exclude=Thumbs.db \
    --exclude=temp \
    --exclude=tmp \
    --exclude=.env.local \
    --exclude=.env.*.local \
    --exclude=coverage \
    --exclude=.nyc_output \
    --exclude=.vscode \
    --exclude=.idea \
    --exclude=*.tmp \
    --exclude=*.temp \
    src/ public/ package.json package-lock.json tailwind.config.ts next.config.ts tsconfig.json eslint.config.mjs prisma/ db/ server.ts README.md backup-system/

if [ $? -eq 0 ]; then
    echo "✅ Archive created successfully"
else
    echo "❌ Failed to create archive"
    exit 1
fi

echo "📤 Pushing to GitHub..."

# Clone repository with authentication
AUTH_REPO_URL="${GITHUB_REPO/https:\/\//https:\/\/$GITHUB_TOKEN@}"
git clone "$AUTH_REPO_URL" "$TEMP_DIR/repo"

if [ $? -ne 0 ]; then
    echo "❌ Failed to clone repository"
    rm -rf "$TEMP_DIR"
    exit 1
fi

# Create backups directory in repository
mkdir -p "$TEMP_DIR/repo/backups"

# Copy backup to repository
cp "$TEMP_DIR/$ARCHIVE_NAME" "$TEMP_DIR/repo/backups/"

# Configure git
cd "$TEMP_DIR/repo"
git config user.name "Saanify Backup Bot"
git config user.email "backup@saanify.com"

# Add, commit and push
git add .
git commit -m "🚀 Saanify Backup: $(date -Iseconds)"

# Check if this is the first commit (empty repo)
if git ls-remote --exit-code origin "$GITHUB_BRANCH" >/dev/null 2>&1; then
    # Branch exists, push normally
    git push origin "$GITHUB_BRANCH"
else
    # Branch doesn't exist, create it
    echo "📝 Creating initial branch..."
    git push -u origin "$GITHUB_BRANCH" --force
fi

if [ $? -eq 0 ]; then
    echo "✅ Backup pushed to GitHub successfully!"
    echo "📍 Backup URL: ${GITHUB_REPO}/tree/${GITHUB_BRANCH}/backups/${ARCHIVE_NAME}"
else
    echo "❌ Failed to push to GitHub"
    cd ../..
    rm -rf "$TEMP_DIR"
    exit 1
fi

# Cleanup
cd ../..
rm -rf "$TEMP_DIR"

echo "🎉 GitHub backup completed successfully!"