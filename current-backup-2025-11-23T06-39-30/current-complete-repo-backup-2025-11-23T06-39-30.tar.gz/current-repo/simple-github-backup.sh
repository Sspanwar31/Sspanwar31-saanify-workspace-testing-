#!/bin/bash

# Simple GitHub Backup Script
echo "🚀 Starting simple GitHub backup..."

# Configuration
GITHUB_REPO="https://github.com/Sspanwar31/Sspanwar31-saanify-workspace-testing-"
GITHUB_TOKEN="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"
TIMESTAMP=$(date +"%Y-%m-%dT%H-%M-%S")
ARCHIVE_NAME="saanify-backup-${TIMESTAMP}.tar.gz"

echo "📦 Creating backup archive..."

# Create backup
tar -czf "$ARCHIVE_NAME" \
    --exclude=node_modules \
    --exclude=.next \
    --exclude=dist \
    --exclude=.git \
    --exclude=*.log \
    --exclude=temp \
    --exclude=tmp \
    src/ public/ package.json package-lock.json tailwind.config.ts next.config.ts tsconfig.json eslint.config.mjs prisma/ db/ server.ts README.md backup-system/ 2>/dev/null

if [ $? -eq 0 ]; then
    echo "✅ Archive created: $ARCHIVE_NAME"
else
    echo "❌ Failed to create archive"
    exit 1
fi

# Initialize git if not already done and push to GitHub
AUTH_REPO_URL="${GITHUB_REPO/https:\/\//https:\/\/$GITHUB_TOKEN@}"

# Create a temporary directory for git operations
TEMP_DIR="temp-git-$(date +%s)"
mkdir -p "$TEMP_DIR"
cd "$TEMP_DIR"

# Initialize and set up git
git init
git config user.name "Saanify Backup Bot"
git config user.email "backup@saanify.com"

# Add remote
git remote add origin "$AUTH_REPO_URL"

# Copy the backup file
cp "../$ARCHIVE_NAME" .

# Create backups directory structure
mkdir -p backups
mv "$ARCHIVE_NAME" backups/

# Add and commit
git add .
git commit -m "🚀 Saanify Backup: $(date -Iseconds)"

# Try to push (this will work even on empty repos)
echo "📤 Pushing to GitHub..."
if git push -u origin main --force 2>/dev/null || git push -u origin master --force 2>/dev/null; then
    echo "✅ Backup pushed to GitHub successfully!"
    echo "📍 Repository: $GITHUB_REPO"
else
    echo "⚠️  Push failed, but backup archive is created locally: $ARCHIVE_NAME"
fi

# Cleanup
cd ..
rm -rf "$TEMP_DIR"

echo "🎉 Backup process completed!"